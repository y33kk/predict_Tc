
```
predict_tc_main/
├── config.json          all model / training hyperparameters
├── tc_model.ipynb       Colab notebook: trains the model and evaluates it on the test split
├── README.md            this file
├── predict_tc_main.zip  everything above bundled for Colab (has a predict_tc_main/ root folder)
├── data/
│   ├── tc_data.json.gz   1,915 consolidated hydride records, each with Tc
│   └── groups.json.gz    5-fold split for cross-validation
└── results/              saved output of the latest run (not needed to run the notebook)
    ├── predictions.csv   final predictions for all 1,915 records
    └── models/           weights of the 15 trained ALIGNN networks (g{group}_{member}.pt)
```

Every run trains all networks from scratch — nothing is cached or reused between runs. The notebook ends with a single `predictions.csv` plus the trained network weights, bundled into `results.zip` (a copy of the latest such run is in `results/`).

## Data

One consolidated dataset merged from three sources: the Wines & Choudhary paper (via JARVIS), CompSC, and alex_supercon.

- **Tc label.** Each record's Tc comes from the Allen–Dynes formula with μ\* = 0.1. The paper gives it directly; for CompSC and alex_supercon it is computed from λ and ω_log.
- **Duplicate records.** Identical structures at the same pressure are merged (the higher-priority source is kept: paper > CompSC > alex).
- **Within-source conflicts.** Identical structures (matched with pymatgen's StructureMatcher) at the same pressure but with different Tc inside the *same* source have no priority rule, so both records of each such pair were dropped: GeH3 at 180 GPa, NaH6 at 500 GPa, ScH3 at 0 GPa. Other records that share a formula and pressure are different polymorphs and are kept.
- **Record fields:** `formula`, `chemsys`, `pressure_GPa`, `Tc_K`, `atoms` are used by the model; `lambda`, `wlog_K` are reference-only; `provenance` records the origin (source, original id, DOI).
- **Group split.** Chemical systems are split into 5 groups, balanced by record count, Tc distribution, and pressure. Source is not used when forming the groups. Each record appears exactly once in a test set, and the test/validation chemical systems of a group never appear in its training set.

## Model

**Final prediction = 0.5 · ALIGNN×3 + 0.5 · MACE.** ALIGNN is the core; MACE complements it.

- **ALIGNN×3** — three ALIGNN graph networks on the crystal structure (12 nearest neighbours within 8 Å plus bond angles; each atom's up-to-92 element features are extended with pressure, volume per atom, and the hydrogen fraction). They differ by one setting: `huber` — base, `huber_log` — trained on log(1 + Tc), `huber_256` — hidden width 256 instead of 128. The prediction is the mean of the three. Training: AdamW, lr 1e-3, OneCycle schedule, 80 epochs, batch size 32.
- **MACE** — structural features from the pretrained MACE-MP-0 (medium) interatomic potential (trained on ~1.5M DFT energy/force calculations). Per-atom feature vectors are pooled by mean over all atoms, over H atoms, and over non-H atoms, then extended with the same three global features. A small head network (2 hidden layers) is trained on top, AdamW, up to 200 epochs, averaged over 3 seeds. MACE itself is **not** fine-tuned — it is a fixed feature extractor.
- **Loss** for all networks: Huber on normalized Tc (threshold 0.2 normalized units ≈ 9 K). This fits the heavily right-skewed Tc distribution better than MSE (over-sensitive to rare high-Tc outliers) or L1 (indifferent to error size).
- **Epoch selection:** lowest MAE on the validation split.
- **Evaluation:** each record is predicted only by the models of the group where it sits in the test split — models that never saw it. Metrics (MAE, RMSE, R²) are reported over all 1,915 records together.

## Results

Test set, all 1,915 records, 5-fold cross-validation by chemical system:

| | MAE, K | RMSE, K | R² |
|---|---|---|---|
| ALIGNN×3 only | 14.07 | 26.79 | 0.669 |
| MACE only | 14.37 | 28.02 | 0.638 |
| **0.5 · ALIGNN×3 + 0.5 · MACE (final)** | **13.31** | **25.40** | **0.703** |

Baseline "always predict the mean Tc": MAE 31.7 K. The combination beats ALIGNN×3 alone by 0.76 K and does so in all 5 folds. Per-fold MAE of the final model: 16.9 / 11.1 / 12.8 / 14.1 / 11.5 K.

Error grows with Tc — the model systematically **underestimates high Tc** (the main weakness), because such records are rare:

| Tc, K | records | MAE, K | mean bias, K |
|---|---|---|---|
| 0–20 | 1,372 | 6.0 | +3.8 |
| 20–50 | 210 | 23.1 | +9.1 |
| 50–100 | 160 | 27.3 | +2.1 |
| 100–150 | 102 | 30.5 | −17.8 |
| 150–200 | 44 | 60.2 | −56.1 |
| 200+ | 27 | 83.1 | −83.1 |

For Tc ≥ 100 K (173 records, < 10% of the data) MAE is 46.3 K. This is the main open problem; reweighting and extra regularization were both tried and neither helped.

